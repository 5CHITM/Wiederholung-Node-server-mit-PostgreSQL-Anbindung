/* eslint no-unused-vars: off */

const errorHandler = (err, req, res, next) => {
};
const notFound = (req, res) => {
};

module.exports = { errorHandler, notFound };
